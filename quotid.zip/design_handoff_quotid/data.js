/* global React */
// Mock data for Quotid prototype

const MOCK_USER = {
  name: "John Moorman",
  email: "john@johnmoorman.com",
  phone: "+49 176 3032 1460",
  timezone: "Europe/Berlin",
  initials: "JM",
};

const MOCK_SCHEDULE = {
  enabled: true,
  time: "21:00",
  days: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  timezone: "Europe/Berlin",
};

// transcripts: bot opens, user replies, bot follow-up, user, bot wrap.
const TRANSCRIPT_FULL = [
  { who: "bot", t: "00:00", text: "Hey John, it's your nightly check-in. Tell me about something that happened today — small or big, doesn't matter." },
  { who: "user", t: "00:08", text: "Honestly, today felt like it was held together with tape. I had three calls back-to-back, and right in the middle the deploy on the bot service started timing out. I was trying to debug while pretending I was on mute and listening." },
  { who: "bot", t: "00:24", text: "What gave it away that something was off?" },
  { who: "user", t: "00:27", text: "I think it was the second call — someone asked me a direct question and I had to ask them to repeat it. That little flush of being caught half-there. But also kind of funny, in retrospect." },
  { who: "bot", t: "00:42", text: "How did the deploy end up?" },
  { who: "user", t: "00:46", text: "Fixed it on the train home. Forwarded headers, again. I keep getting bitten by that one. Felt good to close the loop before dinner." },
  { who: "bot", t: "01:00", text: "Got it — sleep well, John." },
];

const TRANSCRIPT_SHORT = [
  { who: "bot", t: "00:00", text: "Hey John, it's your nightly check-in. Tell me about something that happened today — small or big, doesn't matter." },
  { who: "user", t: "00:09", text: "I went for a run along the canal even though it was cold. The light on the water was that flat winter silver, and there was a guy fishing with no fish around for a kilometer." },
  { who: "bot", t: "00:24", text: "What stuck with you about that?" },
  { who: "user", t: "00:27", text: "Just the patience of it. I'm not patient like that. Made me feel weirdly calm for the rest of the afternoon." },
  { who: "bot", t: "00:38", text: "Got it — sleep well." },
];

const ENTRIES = [
  {
    id: "e1b",
    date: "2026-04-25",
    timeOfDay: "23:14",
    title: "Late add — actually proud of the fix",
    body: `Came back to log one more thing. The forwarded-headers fix isn't just a band-aid — I finally wrote the helper I should've written weeks ago. Three call-sites collapsed into one import.\n\nQuiet pride. The kind that doesn't need an audience.`,
    duration: 38,
    transcript: TRANSCRIPT_SHORT,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e1",
    date: "2026-04-25",
    timeOfDay: "21:00",
    title: "The deploy held together with tape",
    body: `Today felt held together with tape. Three calls back-to-back, and the bot service deploy started timing out right in the middle of the second one. I was on mute, half-debugging, half-pretending I was listening. Someone asked me a direct question and I had to ask them to repeat it.

Fixed it on the train home — forwarded headers again. The same thing keeps biting me. But it felt good to close the loop before dinner.`,
    duration: 72,
    transcript: TRANSCRIPT_FULL,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e2",
    date: "2026-04-24",
    timeOfDay: "21:02",
    title: "A patient man, no fish",
    body: `Ran along the canal in flat winter light. There was a guy fishing on the bank with no fish around for at least a kilometer.

Just the patience of it stuck with me. I'm not patient like that. It made me feel weirdly calm for the rest of the afternoon.`,
    duration: 41,
    transcript: TRANSCRIPT_SHORT,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e3",
    date: "2026-04-23",
    timeOfDay: "21:00",
    title: "Phone went straight to voicemail",
    body: null,
    duration: null,
    transcript: null,
    edited: false,
    status: "NO_ANSWER",
  },
  {
    id: "e4",
    date: "2026-04-22",
    timeOfDay: "21:00",
    title: "Found a 1991 grammar book at a flea market",
    body: `Wandered through Boxhagener Platz on lunch break and bought a German grammar book from 1991 for two euros. The kind with that brittle GDR paper, full of someone's pencil notes in the margins. They underlined every modal verb.

I'm not going to read it but I love that someone did, hard, three decades ago.`,
    duration: 88,
    transcript: TRANSCRIPT_SHORT,
    edited: true,
    status: "COMPLETED",
  },
  {
    id: "e5b",
    date: "2026-04-21",
    timeOfDay: "13:42",
    title: "Lunch alone, watched the cranes",
    body: `Took my sandwich up to the roof of the office. Two cranes on the next block doing the slow lift-and-pivot, completely silent from up there. Watched them for the whole break.\n\nNo phones, no thoughts. First time in maybe a week.`,
    duration: 52,
    transcript: TRANSCRIPT_SHORT,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e5",
    date: "2026-04-21",
    timeOfDay: "21:00",
    title: "Forty-seven open browser tabs",
    body: `Closed forty-seven browser tabs in one go. Half of them were the same Stack Overflow thread, opened from different days like I'd stumble on it again and it would say something different.

Felt like throwing out a pile of old receipts. Made room for tomorrow.`,
    duration: 56,
    transcript: TRANSCRIPT_SHORT,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e6",
    date: "2026-04-19",
    timeOfDay: "21:00",
    title: "Coffee with M. — she's leaving Berlin",
    body: `M. told me over coffee at Bonanza that she's leaving Berlin in June. Going back to Lisbon to be near her mother. We've been doing this Saturday coffee thing for almost two years now and I didn't realize how much I'd built around it until she said the date out loud.

I said the right things. But I felt the room narrow.`,
    duration: 124,
    transcript: TRANSCRIPT_FULL,
    edited: true,
    status: "COMPLETED",
  },
  {
    id: "e7",
    date: "2026-04-18",
    timeOfDay: "21:00",
    title: "Workflow stuck in DIALING for nine minutes",
    body: `Spent the morning chasing a Temporal workflow that got stuck in DIALING for nine minutes before timing out. Turned out the bot pipeline wasn't terminating after the WSS close — needed on_client_disconnected to cancel the task explicitly.

Something satisfying about that fix. Like tightening a single screw and the whole thing stops rattling.`,
    duration: 67,
    transcript: TRANSCRIPT_SHORT,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e8b",
    date: "2026-04-17",
    timeOfDay: "23:48",
    title: "One more — the salsa from the balcony",
    body: `Couldn't sleep. The salsa kept playing in my head. I think it was Buena Vista, but slowed down, or maybe my memory slowed it down.\n\nDecided I want to learn one song on guitar this summer. Just one.`,
    duration: 44,
    transcript: TRANSCRIPT_SHORT,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e8",
    date: "2026-04-17",
    timeOfDay: "21:00",
    title: "First warm evening of the year",
    body: `First evening warm enough to sit outside without a jacket. Got a beer at the Späti and walked along Landwehrkanal until the light went. The whole city was out — kids on bikes, dogs off-leash, somebody's bluetooth speaker playing salsa from a balcony.

Berlin in April pretending it's June. Everyone collectively choosing to believe.`,
    duration: 95,
    transcript: TRANSCRIPT_FULL,
    edited: false,
    status: "COMPLETED",
  },
  {
    id: "e9",
    date: "2026-04-15",
    timeOfDay: "21:00",
    title: "—",
    body: null,
    duration: null,
    transcript: null,
    edited: false,
    status: "NO_ANSWER",
  },
  {
    id: "e10",
    date: "2026-03-31",
    timeOfDay: "21:00",
    title: "Last day of March, somehow already",
    body: `Realized today is the last day of March. I have no idea where the month went. Started writing down what I remember — week by week — and I could only reconstruct three weeks. The other one is just gone.

That's why I built this thing, I guess.`,
    duration: 110,
    transcript: TRANSCRIPT_FULL,
    edited: false,
    status: "COMPLETED",
  },
];

// All call sessions including ones tied to entries plus standalone missed calls
const CALLS = ENTRIES.map((e) => ({
  id: "c-" + e.id,
  date: e.date,
  startedAt: e.date + "T21:00:00Z",
  duration: e.duration,
  status: e.status,
  entryId: e.body ? e.id : null,
  entryTitle: e.title,
  failureReason: e.status === "NO_ANSWER" ? "No answer after 4 rings" : null,
}));

window.MOCK = { MOCK_USER, MOCK_SCHEDULE, ENTRIES, CALLS, TRANSCRIPT_FULL, TRANSCRIPT_SHORT };
