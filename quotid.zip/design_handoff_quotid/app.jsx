/* global React, ReactDOM, MOCK, UI, SCREENS, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakSlider, TweakColor, TweakSelect, TweakButton */
const { useState, useEffect, useRef, useMemo } = React;
const { Sidebar } = UI;
const { LoginScreen, JournalIndex, EntryDetail, CallsList, Settings, LiveCall } = SCREENS;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentHue": 55,
  "typeset": "default",
  "density": "comfortable",
  "dark": false,
  "showLogin": false,
  "simulateCall": "off"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [authed, setAuthed] = useState(!tweaks.showLogin);
  const [route, setRoute] = useState("journal");
  const [openEntryId, setOpenEntryId] = useState(null);
  const [openCallEntry, setOpenCallEntry] = useState(null);
  const [callPhase, setCallPhase] = useState("off"); // off | dialing | in-progress | minimized
  const [entries, setEntries] = useState(MOCK.ENTRIES);
  const [schedule, setSchedule] = useState(MOCK.MOCK_SCHEDULE);

  // re-mirror showLogin changes
  useEffect(() => { setAuthed(!tweaks.showLogin); }, [tweaks.showLogin]);

  // simulate call from tweaks
  useEffect(() => {
    if (tweaks.simulateCall === "dialing") setCallPhase("dialing");
    else if (tweaks.simulateCall === "in-progress") setCallPhase("in-progress");
    else if (tweaks.simulateCall === "off") setCallPhase("off");
  }, [tweaks.simulateCall]);

  // apply theme attrs to root
  useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty("--accent-h", tweaks.accentHue);
    r.dataset.theme = tweaks.dark ? "dark" : "light";
    r.dataset.density = tweaks.density;
    r.dataset.typeset = tweaks.typeset;
  }, [tweaks]);

  const triggerCall = () => setCallPhase("dialing");
  const enterCall = () => setCallPhase("in-progress");
  const endCall = () => { setCallPhase("off"); setTweak("simulateCall", "off"); };
  const minimize = () => setCallPhase("minimized");

  const openEntry = entries.find((e) => e.id === openEntryId);

  if (!authed) {
    return (
      <>
        <LoginScreen onSubmit={() => { setAuthed(true); setTweak("showLogin", false); }} />
        <Tweaks tweaks={tweaks} setTweak={setTweak} />
      </>
    );
  }

  return (
    <div className="app">
      <Sidebar
        route={route}
        setRoute={(r) => { setRoute(r); setOpenEntryId(null); setOpenCallEntry(null); }}
        onLogout={() => setAuthed(false)}
        dark={tweaks.dark}
        onToggleTheme={() => setTweak("dark", !tweaks.dark)}
      />
      <main className="main">
        {openEntryId ? (
          <EntryDetail
            entry={openEntry}
            onBack={() => setOpenEntryId(null)}
            onEdit={(id, body) => setEntries((es) => es.map((e) => e.id === id ? { ...e, body, edited: true } : e))}
          />
        ) : route === "journal" ? (
          <JournalIndex
            entries={entries}
            schedule={schedule}
            callState={callPhase === "minimized" ? "in-progress" : callPhase}
            onOpenEntry={setOpenEntryId}
            onTrigger={triggerCall}
            onEnter={enterCall}
          />
        ) : route === "calls" ? (
          <CallsList
            calls={MOCK.CALLS}
            onOpen={(c) => { if (c.entryId) setOpenEntryId(c.entryId); else setOpenEntryId(c.id.slice(2)); }}
          />
        ) : route === "settings" ? (
          <Settings schedule={schedule} setSchedule={setSchedule} user={MOCK.MOCK_USER} />
        ) : null}
      </main>

      {(callPhase === "dialing" || callPhase === "in-progress") && (
        <LiveCall phase={callPhase} onEnd={endCall} onConnect={enterCall} />
      )}

      <Tweaks tweaks={tweaks} setTweak={setTweak} />
    </div>
  );
}

function Tweaks({ tweaks, setTweak }) {
  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Theme">
        <TweakSlider label="Accent hue" value={tweaks.accentHue} min={0} max={360} step={1} unit="°" onChange={(v) => setTweak("accentHue", v)} />
        <TweakToggle label="Dark mode" value={tweaks.dark} onChange={(v) => setTweak("dark", v)} />
        <TweakRadio label="Type" value={tweaks.typeset} options={["default", "sans", "serif", "editorial"]} onChange={(v) => setTweak("typeset", v)} />
        <TweakRadio label="Density" value={tweaks.density} options={["comfortable", "cozy"]} onChange={(v) => setTweak("density", v)} />
      </TweakSection>
      <TweakSection label="Demo state">
        <TweakToggle label="Show login" value={tweaks.showLogin} onChange={(v) => setTweak("showLogin", v)} />
        <TweakRadio label="Simulate call" value={tweaks.simulateCall} options={["off", "dialing", "in-progress"]} onChange={(v) => setTweak("simulateCall", v)} />
      </TweakSection>
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
