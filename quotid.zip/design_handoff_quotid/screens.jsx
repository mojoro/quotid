/* global React, MOCK, UI */
const { useState, useEffect, useRef, useMemo } = React;
const { Sidebar, PulseDot, fmtDuration, fmtMonth, fmtDay, fmtLong, QCordMark } = UI;

// ── Login ─────────────────────────────────────────────────────────────────
function LoginScreen({ onSubmit }) {
  const [code, setCode] = useState("");
  const [err, setErr] = useState(null);
  return (
    <main className="auth">
      <div className="auth__card">
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 24 }} aria-hidden="true">
          <QCordMark size={56} strokeWidth={26} color="var(--accent)" />
        </div>
        <h1 className="auth__brand">quotid</h1>
        <p className="auth__tag">A nightly call, a daily entry.</p>
        <form
          className="auth__form"
          onSubmit={(e) => {
            e.preventDefault();
            if (code.length < 4) { setErr("Enter your passcode."); return; }
            onSubmit();
          }}
        >
          <input
            className="input"
            type="password"
            placeholder="passcode"
            value={code}
            autoFocus
            aria-label="Passcode"
            aria-invalid={err ? "true" : "false"}
            aria-describedby={err ? "auth-error" : undefined}
            onChange={(e) => { setCode(e.target.value); setErr(null); }}
          />
          <button className="btn btn--big" type="submit" style={{ justifyContent: "center" }}>Sign in</button>
          {err && <p id="auth-error" className="tiny" style={{ color: "var(--bad)" }} role="alert">{err}</p>}
        </form>
        <p className="tiny muted" style={{ marginTop: 32 }}>
          Need an account? <a href="#" style={{ color: "var(--accent-ink)" }}>Get an invite</a>
        </p>
      </div>
    </main>
  );
}

// ── Status card on Journal ────────────────────────────────────────────────
function StatusCard({ schedule, callState, onTrigger, onEnter }) {
  const live = callState === "in-progress" || callState === "dialing";

  if (live) {
    return (
      <div className="status status--live">
        <div>
          <div className="status__label" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <PulseDot /> {callState === "dialing" ? "Calling you…" : "On the call"}
          </div>
          <div className="status__title">{callState === "dialing" ? "Your phone should ring in a moment" : "Tonight's check-in is happening"}</div>
          <div className="status__sub">+49 176 3032 1460 · Pick up when you're ready</div>
        </div>
        <button className="btn btn--accent" onClick={onEnter}>Open call →</button>
      </div>
    );
  }

  return (
    <div className="status">
      <div>
        <div className="status__label">Tonight</div>
        <div className="status__title">
          {schedule.enabled ? `Quotid will call you at ${schedule.time}` : `Auto-call is paused`}
        </div>
        <div className="status__sub">
          {schedule.enabled
            ? `${MOCK.MOCK_USER.phone} · ${schedule.timezone}`
            : `Turn it back on in Settings, or call now whenever you want.`}
        </div>
      </div>
      <button className="btn" onClick={onTrigger}>Call me now</button>
    </div>
  );
}

// ── Journal index ─────────────────────────────────────────────────────────
function JournalIndex({ entries, schedule, callState, onOpenEntry, onTrigger, onEnter }) {
  // group entries by month
  const groups = useMemo(() => {
    const map = new Map();
    for (const e of entries) {
      const k = fmtMonth(e.date);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(e);
    }
    return Array.from(map.entries());
  }, [entries]);

  const today = new Date();
  const greeting = today.getHours() < 12 ? "Good morning" : today.getHours() < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="route">
      <div className="eyebrow">{greeting}, John</div>
      <h1 className="h1" style={{ marginTop: 8 }}>
        Your <em>journal</em>, born from conversation.
      </h1>
      <StatusCard
        schedule={schedule}
        callState={callState}
        onTrigger={onTrigger}
        onEnter={onEnter}
      />

      {groups.map(([month, items]) => (
        <section className="month" key={month}>
          <div className="month__label">{month}</div>
          <div className="entries">
            {items.map((e, i) => {
              const prev = items[i - 1];
              const isContinuation = prev && prev.date === e.date;
              const next = items[i + 1];
              const hasContinuation = next && next.date === e.date;
              return (
                <button
                  key={e.id}
                  className={"entry-row" + (isContinuation ? " entry-row--cont" : "") + (hasContinuation ? " entry-row--has-cont" : "")}
                  onClick={() => onOpenEntry(e.id)}
                >
                  <div className="entry-row__day">
                    {isContinuation ? (
                      <div className="entry-row__time">{e.timeOfDay || "—"}</div>
                    ) : (
                      <>
                        {fmtDay(e.date)}
                        {hasContinuation && <div className="entry-row__time entry-row__time--first">{e.timeOfDay || ""}</div>}
                      </>
                    )}
                  </div>
                  <div>
                    <div className="entry-row__title">{e.title}</div>
                    <div className="entry-row__sub">
                      {e.status === "NO_ANSWER" ? (
                        <span className="pill pill--missed">No answer</span>
                      ) : (
                        <span className="muted tiny">{fmtDuration(e.duration)} call</span>
                      )}
                      {e.edited && <span className="pill pill--edited">edited</span>}
                    </div>
                  </div>
                  <div className="entry-row__meta">
                    {isContinuation ? "" : new Date(e.date).toLocaleString(undefined, { weekday: "short" })}
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      ))}

      <div style={{ height: 80 }} />
    </div>
  );
}

// ── Audio player (mocked) ─────────────────────────────────────────────────
function RecordingPlayer({ duration }) {
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const waveRef = useRef(null);
  const draggingRef = useRef(false);

  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setPos((p) => {
        if (p >= duration) { setPlaying(false); return 0; }
        return p + 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [playing, duration]);

  // generate a static-looking waveform from duration
  const bars = useMemo(() => {
    const N = 56;
    const seed = duration || 60;
    const arr = [];
    for (let i = 0; i < N; i++) {
      // pseudo-random but stable
      const v = (Math.sin(i * 1.3 + seed) * 0.5 + 0.5) * 0.7 + 0.18 * Math.abs(Math.sin(i * 0.6));
      arr.push(Math.min(1, Math.max(0.18, v)));
    }
    return arr;
  }, [duration]);

  const playedFraction = duration ? Math.min(1, pos / duration) : 0;
  const playedIdx = Math.floor(playedFraction * bars.length);

  function seekFromEvent(e) {
    const node = waveRef.current;
    if (!node) return;
    const r = node.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    const f = Math.max(0, Math.min(1, x / r.width));
    setPos(Math.floor(duration * f));
  }
  function onPointerDown(e) {
    draggingRef.current = true;
    e.currentTarget.setPointerCapture?.(e.pointerId);
    seekFromEvent(e);
  }
  function onPointerMove(e) {
    if (!draggingRef.current) return;
    seekFromEvent(e);
  }
  function onPointerUp() {
    draggingRef.current = false;
  }

  return (
    <div className="player" role="region" aria-label="Recording playback">
      <button
        type="button"
        className="player__btn"
        onClick={() => setPlaying((p) => !p)}
        aria-label={playing ? "Pause recording" : "Play recording"}
      >
        {playing ? <ICONS.IconPause size={16} /> : <ICONS.IconPlay size={16} />}
      </button>
      <div
        ref={waveRef}
        className="player__wave"
        role="slider"
        tabIndex={0}
        aria-label="Seek within recording"
        aria-valuemin={0}
        aria-valuemax={duration || 0}
        aria-valuenow={pos}
        aria-valuetext={`${fmtDuration(pos)} of ${fmtDuration(duration)}`}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") { e.preventDefault(); setPos((p) => Math.min(duration, p + 5)); }
          if (e.key === "ArrowLeft") { e.preventDefault(); setPos((p) => Math.max(0, p - 5)); }
          if (e.key === " " || e.key === "Enter") { e.preventDefault(); setPlaying((p) => !p); }
        }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      >
        {bars.map((h, i) => (
          <span
            key={i}
            className={"player__wave__bar " + (i < playedIdx ? "is-played" : "")}
            style={{ height: `${Math.round(h * 100)}%` }}
          />
        ))}
      </div>
      <div className="player__time">{fmtDuration(pos)} / {fmtDuration(duration)}</div>
    </div>
  );
}

// ── Entry detail ──────────────────────────────────────────────────────────
function EntryDetail({ entry, onBack, onEdit }) {
  const [editing, setEditing] = useState(false);
  const [body, setBody] = useState(entry.body || "");
  const [showT, setShowT] = useState(false);

  if (!entry) return null;

  if (entry.status === "NO_ANSWER") {
    return (
      <div className="route entry-doc">
        <button type="button" className="icon-btn" onClick={onBack} aria-label="Back to journal" style={{ marginBottom: 24 }}><ICONS.IconArrowLeft size={18} /></button>
        <div className="entry-doc__date">{fmtLong(entry.date)}</div>
        <h1 className="entry-doc__title"><em>We tried</em>, but couldn't reach you.</h1>
        <p className="entry-doc__body" style={{ marginTop: 24, fontSize: 17 }}>
          Quotid called you at 21:00 on this day. The call rang out after four tries, so no entry was created.
          {"\n\n"}If you'd like, you can record one now.
        </p>
        <div style={{ marginTop: 28, display: "flex", gap: 10 }}>
          <button className="btn">Call me now</button>
          <button className="btn btn--ghost" onClick={onBack}>Skip</button>
        </div>
      </div>
    );
  }

  return (
    <div className="route entry-doc">
      <div className="entry-doc__topbar">
        <button type="button" className="icon-btn" onClick={onBack} aria-label="Back to journal"><ICONS.IconArrowLeft size={18} /></button>
        <div style={{ display: "flex", gap: 8 }}>
          {!editing && <button type="button" className="icon-btn" onClick={() => setEditing(true)} aria-label="Edit entry"><ICONS.IconEdit size={18} /></button>}
          {editing && <button type="button" className="icon-btn icon-btn--solid" onClick={() => { setEditing(false); onEdit(entry.id, body); }} aria-label="Save entry"><ICONS.IconCheck size={18} /></button>}
        </div>
      </div>

      <div className="entry-doc__date">{fmtLong(entry.date)}</div>
      <h1 className="entry-doc__title">{entry.title}</h1>

      <article
        className="entry-doc__body"
        contentEditable={editing}
        suppressContentEditableWarning
        onBlur={(e) => setBody(e.currentTarget.innerText)}
      >{body}</article>

      <RecordingPlayer duration={entry.duration} />

      <button className="transcript-toggle" onClick={() => setShowT((s) => !s)}>
        {showT ? "Hide transcript" : `View transcript · ${entry.transcript.length} turns`}
      </button>

      {showT && (
        <div className="transcript">
          {entry.transcript.map((turn, i) => (
            <div className="turn" key={i}>
              <div className={"turn__who" + (turn.who === "bot" ? " turn__who--bot" : "")}>
                {turn.who === "bot" ? "Quotid" : "John"}
                <div className="turn__time">{turn.t}</div>
              </div>
              <div className="turn__text">{turn.text}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ height: 80 }} />
    </div>
  );
}

// ── Calls list ────────────────────────────────────────────────────────────
function CallsList({ calls, onOpen }) {
  return (
    <div className="route">
      <div className="eyebrow">All calls</div>
      <h1 className="h1" style={{ marginTop: 8 }}>Conversation log</h1>
      <p className="muted" style={{ marginTop: 12, maxWidth: 540 }}>
        Every check-in attempt, completed or missed. Listen back, re-read what we said, or jump to the journal entry.
      </p>

      <div style={{ marginTop: 36 }}>
        {calls.map((c) => (
          <button key={c.id} className="call-row" onClick={() => onOpen(c)}>
            <div className="call-row__date">
              {new Date(c.date).toLocaleDateString(undefined, { month: "short", day: "2-digit" })}
              <div style={{ color: "var(--ink-4)", marginTop: 2 }}>21:00</div>
            </div>
            <div className="call-row__title">
              {c.entryTitle === "—" ? <span className="muted">No journal entry</span> : c.entryTitle}
              <small>
                {c.status === "COMPLETED" && "Completed · transcript available"}
                {c.status === "NO_ANSWER" && "No answer · " + c.failureReason}
                {c.status === "FAILED" && "Failed · " + c.failureReason}
              </small>
            </div>
            <div>
              {c.status === "COMPLETED" && <span className="pill" style={{ background: "var(--paper-3)" }}>completed</span>}
              {c.status === "NO_ANSWER" && <span className="pill pill--missed">missed</span>}
              {c.status === "FAILED" && <span className="pill pill--missed">failed</span>}
            </div>
            <div className="call-row__dur">{fmtDuration(c.duration)}</div>
          </button>
        ))}
      </div>

      <div style={{ height: 80 }} />
    </div>
  );
}

// ── Voice picker ──────────────────────────────────────────────────────────
const VOICES = [
  { id: "asteria", name: "Asteria", desc: "Warm, mid-range, evening", sample: "Hey John, it's your nightly check-in. Tell me about your day." },
  { id: "orion", name: "Orion", desc: "Lower, slower, contemplative", sample: "Take your time. Just one thing from today, however small." },
  { id: "helios", name: "Helios", desc: "Bright, lifted, friendly", sample: "Hi! I'm here for the daily — what stood out for you today?" },
  { id: "nova", name: "Nova", desc: "Soft, breathy, intimate", sample: "Ready when you are. Tell me one moment from today." },
];

function VoicePicker() {
  const [selected, setSelected] = useState("asteria");
  const [playing, setPlaying] = useState(null);
  useEffect(() => {
    if (!playing) return;
    const t = setTimeout(() => setPlaying(null), 2400);
    return () => clearTimeout(t);
  }, [playing]);

  return (
    <div className="voice-list">
      {VOICES.map((v) => {
        const isOn = selected === v.id;
        const isPlaying = playing === v.id;
        return (
          <button
            key={v.id}
            type="button"
            className={"voice-card" + (isOn ? " is-on" : "")}
            onClick={() => setSelected(v.id)}
          >
            <span
              className={"voice-card__play" + (isPlaying ? " is-playing" : "")}
              onClick={(e) => { e.stopPropagation(); setPlaying(isPlaying ? null : v.id); }}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); setPlaying(isPlaying ? null : v.id); } }}
              aria-label={isPlaying ? `Stop preview of ${v.name}` : `Preview ${v.name}`}
            >
              {isPlaying ? <ICONS.IconStop size={14} /> : <ICONS.IconPlay size={14} />}
            </span>
            <div>
              <div className="voice-card__name">
                {v.name}
                {isPlaying && (
                  <span className="voice-card__wave" aria-hidden="true">
                    <span /><span /><span /><span />
                  </span>
                )}
              </div>
              <div className="voice-card__sample">"{v.sample}" · {v.desc}</div>
            </div>
            <span className="voice-card__check">✓</span>
          </button>
        );
      })}
    </div>
  );
}

// ── Settings ──────────────────────────────────────────────────────────────
function Settings({ schedule, setSchedule, user }) {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const [hh, mm] = schedule.time.split(":");

  function setTime(newHH, newMM) {
    const h = String(Math.max(0, Math.min(23, +newHH || 0))).padStart(2, "0");
    const m = String(Math.max(0, Math.min(59, +newMM || 0))).padStart(2, "0");
    setSchedule({ ...schedule, time: `${h}:${m}` });
  }

  function toggleDay(d) {
    const has = schedule.days.includes(d);
    setSchedule({ ...schedule, days: has ? schedule.days.filter((x) => x !== d) : [...schedule.days, d] });
  }

  return (
    <div className="route">
      <div className="eyebrow">Settings</div>
      <h1 className="h1" style={{ marginTop: 8 }}>How and when to call.</h1>

      <section style={{ marginTop: 48 }}>
        <h2 className="h2">Nightly call</h2>
        <div className="settings__row">
          <div>
            <div className="settings__label">Auto-call</div>
            <div className="settings__hint">When on, we'll call you every selected day at your chosen time.</div>
          </div>
          <div>
            <button
              type="button"
              className={"toggle" + (schedule.enabled ? " is-on" : "")}
              role="switch"
              aria-checked={schedule.enabled}
              aria-label="Auto-call"
              onClick={() => setSchedule({ ...schedule, enabled: !schedule.enabled })}
            >
              <span className="toggle__knob" aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="settings__row">
          <div>
            <div className="settings__label">Time of day</div>
            <div className="settings__hint">Pick a time you're usually winding down. We're best at the boundary between day and sleep.</div>
          </div>
          <div>
            <div className="time-picker" role="group" aria-label="Call time">
              <input type="number" min="0" max="23" value={hh} onChange={(e) => setTime(e.target.value, mm)} aria-label="Hour" />
              <span aria-hidden="true">:</span>
              <input type="number" min="0" max="59" value={mm} onChange={(e) => setTime(hh, e.target.value)} aria-label="Minute" />
            </div>
            <div className="settings__hint" style={{ marginTop: 8 }}>{schedule.timezone} (your phone's time zone)</div>
          </div>
        </div>

        <div className="settings__row">
          <div>
            <div className="settings__label">Days</div>
            <div className="settings__hint">Skip days you'd rather not be interrupted.</div>
          </div>
          <div>
            <div className="day-pick" role="group" aria-label="Days of the week">
              {days.map((d) => (
                <button
                  type="button"
                  key={d}
                  className={schedule.days.includes(d) ? "is-on" : ""}
                  onClick={() => toggleDay(d)}
                  aria-pressed={schedule.days.includes(d)}
                  aria-label={d}
                ><span aria-hidden="true">{d.slice(0, 1)}</span></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section style={{ marginTop: 56 }}>
        <h2 className="h2">Account</h2>
        <div className="settings__row">
          <div><div className="settings__label">Phone number</div>
            <div className="settings__hint">The number Quotid will call. Verified.</div>
          </div>
          <div>
            <input className="input" type="tel" defaultValue={user.phone} aria-label="Phone number" />
          </div>
        </div>
        <div className="settings__row">
          <div><div className="settings__label">Email</div>
            <div className="settings__hint">For login and recovery.</div>
          </div>
          <div>
            <input className="input" type="email" defaultValue={user.email} aria-label="Email" />
          </div>
        </div>
        <div className="settings__row">
          <div><div className="settings__label">Voice</div>
            <div className="settings__hint">Pick the agent voice you'll hear.</div>
          </div>
          <VoicePicker />
        </div>
        <div className="settings__row">
          <div><div className="settings__label">Danger zone</div>
            <div className="settings__hint">Delete your account and every recording. This can't be undone.</div>
          </div>
          <div><button className="btn btn--danger">Delete account</button></div>
        </div>
      </section>

      <div style={{ height: 80 }} />
    </div>
  );
}

// ── Live call ─────────────────────────────────────────────────────────────
const LIVE_SCRIPT = [
  { who: "bot", text: "Hey John, it's your nightly check-in. Tell me about something that happened today — small or big, doesn't matter.", at: 1500 },
  { who: "user", text: "Today was, um, really long actually. The deploy on the bot was timing out in the middle of three back-to-back calls.", at: 9000 },
  { who: "bot", text: "What gave it away that something was off?", at: 17000 },
  { who: "user", text: "I had to ask someone to repeat their question. That little flush of being caught half-there.", at: 24000 },
];

function LiveCall({ phase, onEnd, onConnect }) {
  const [elapsed, setElapsed] = useState(0);
  const [shown, setShown] = useState([]);
  const [meterVals, setMeterVals] = useState(Array.from({ length: 24 }, () => 0.3));
  const startRef = useRef(null);

  useEffect(() => {
    if (phase !== "in-progress") return;
    startRef.current = Date.now();
    const id = setInterval(() => {
      const e = Math.floor((Date.now() - startRef.current) / 1000);
      setElapsed(e);
    }, 250);
    return () => clearInterval(id);
  }, [phase]);

  // reveal lines
  useEffect(() => {
    if (phase !== "in-progress") return;
    const timeouts = LIVE_SCRIPT.map((line, i) =>
      setTimeout(() => setShown((s) => [...s, i]), line.at)
    );
    return () => timeouts.forEach(clearTimeout);
  }, [phase]);

  // mic meter animation
  useEffect(() => {
    if (phase !== "in-progress") return;
    const id = setInterval(() => {
      setMeterVals((v) => v.map(() => 0.2 + Math.random() * 0.8));
    }, 90);
    return () => clearInterval(id);
  }, [phase]);

  // dialing → in-progress auto
  useEffect(() => {
    if (phase === "dialing") {
      const t = setTimeout(onConnect, 2400);
      return () => clearTimeout(t);
    }
  }, [phase, onConnect]);

  const lastLine = shown.length ? LIVE_SCRIPT[shown[shown.length - 1]] : null;

  return (
    <div className="call-stage">
      <div className="call-stage__head">
        <div className="call-stage__who">
          <div style={{ width: 8, height: 8, background: phase === "in-progress" ? "var(--accent)" : "oklch(96% 0.005 80 / 0.6)", borderRadius: "50%" }} aria-hidden="true" />
          <div style={{ fontSize: 12, letterSpacing: "0.16em", textTransform: "uppercase", color: "oklch(96% 0.005 80 / 0.85)" }}>
            {phase === "dialing" ? "Calling" : "Live · End-to-end encrypted"}
          </div>
        </div>
        <button type="button" className="btn btn--ghost" style={{ borderColor: "oklch(96% 0.005 80 / 0.4)", color: "oklch(96% 0.005 80 / 0.95)" }} onClick={onEnd}>Minimize</button>
      </div>

      <div className="call-stage__center">
        <div className="call-stage__orb" data-phase={phase}>
          <div className="call-stage__avatar" />
        </div>
        <h1 className="call-stage__title">Quotid</h1>
        <div className="call-stage__elapsed">
          {phase === "dialing" ? "Dialing your phone…" : `Connected · ${fmtDuration(elapsed)}`}
        </div>

        <div className="live-caption-slot">
          {phase === "in-progress" && lastLine && (
            <div className="live-caption">
              <div className="live-caption__who">{lastLine.who === "bot" ? "QUOTID" : "JOHN"}</div>
              <div className="live-caption__text">
                {lastLine.text}
                {lastLine.who === "bot" && <span className="live-caption__cursor" />}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="call-stage__foot">
        <div className="call-stage__foot-side call-stage__foot-side--left">
          <div className="mic-meter" aria-hidden="true">
            {meterVals.map((v, i) => (
              <span key={i} style={{ height: `${v * 100}%`, opacity: phase === "in-progress" ? 1 : 0.25 }} />
            ))}
          </div>
          <div className="call-stage__listening" aria-live="polite">
            {phase === "in-progress" ? "Listening" : phase === "dialing" ? "Ringing" : ""}
          </div>
        </div>
        <div className="call-stage__hangup-wrap">
          <button type="button" className="hangup" onClick={onEnd} aria-label="Hang up"><ICONS.IconClose size={26} /></button>
          <div className="call-stage__hangup-label">End call</div>
        </div>
        <div className="call-stage__foot-side call-stage__foot-side--right" />
      </div>
    </div>
  );
}

window.SCREENS = { LoginScreen, JournalIndex, EntryDetail, CallsList, Settings, LiveCall };
