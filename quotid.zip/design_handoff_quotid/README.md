# Handoff: Quotid

> **A nightly call, a daily entry.** A journal product where users receive a 5–10 minute AI voice call at a chosen time each evening, and a written journal entry — generated from the conversation — appears the next morning.

---

## About the design files

The HTML/JSX/CSS files in this bundle are **design references**, not production code to lift wholesale. They are a high-fidelity working prototype built with vanilla React (CDN, in-browser Babel) so the design could be reviewed interactively in a browser.

**Your task:** recreate these designs in the target codebase using its existing patterns, libraries, and conventions. If no codebase exists yet, choose the appropriate framework for the platform (Next.js / Remix for web, SwiftUI for iOS, etc.) and implement against that.

You should treat the prototype as the **source of truth for layout, copy, color, type, spacing, motion, and interaction** — but every detail of the implementation (component library, state management, routing, data layer, build) should follow the host codebase's conventions.

## Fidelity

**High-fidelity.** All colors, typography, spacing, copy, and interaction details are final and intentional. Recreate the visual design pixel-for-pixel. The only things that should change in implementation are the technical foundation (framework, components, routing, data) — not what the user sees.

---

## Product summary

Quotid is a journaling app whose unique mechanic is **journaling by phone call, not by typing**. The core loop:

1. User picks a nightly time window (e.g. 9:00–9:30pm).
2. At that time, an AI voice agent (one of several voices) calls their phone.
3. The user has a 5–10 minute conversation about their day.
4. By the next morning, a written journal entry — drafted from the call — is in the user's journal. The user can read it, listen to the original audio, and view a turn-by-turn transcript.

The visual feel is **a paper notebook, not a chat app**: warm paper palette, editorial serif (Fraunces) for entries and titles, generous whitespace, ritual rather than gamification.

---

## Screens

The app has six primary surfaces:

### 1. Login (`LoginScreen`)
- **Purpose:** Authenticate (placeholder — passcode in the prototype; real implementation will use email magic link or similar).
- **Layout:** Centered single-column card on a paper background with a soft warm-gradient halo at the top.
  - Brand mark (Q-cord, 56px) centered, then italic serif wordmark "quotid", then tagline "A nightly call, a daily entry."
  - Single password input.
  - Big primary CTA "Sign in".
  - Small "Need an account? Get an invite" link below.
- **Components:** `QCordMark`, `.input`, `.btn.btn--big`.

### 2. Journal index (`JournalIndex`)
- **Purpose:** The user's home — every entry, grouped by month, with a status card at the top showing tonight's call window or live-call state.
- **Layout:** Single column, max-width ~720px, generous padding.
  - **Status card** at the top — three states:
    - **Idle:** "Tonight at 9:00pm" with the call number and a small "Test now" affordance.
    - **Dialing:** Pulsing dot, "Calling you…" with phone number; ghost "Open call" button.
    - **In-progress:** Pulsing accent dot, "On the call", "Pick up when you're ready"; primary "Open call →" button.
  - **Month groups** — sticky italic month label on the left, list of entries on the right. Each entry row:
    - Large serif day number (28px, ink-2)
    - Title (19px serif)
    - Snippet (1 line, ink-3)
    - Duration pill on the right
    - Hover: row gets a `paper-2` background tint.
  - **Missed-call pills** appear inline in the month list (small terracotta pill, "Missed · 9:04pm"). Clicking opens the calls list filtered to that day.
- **Empty state:** Italic serif copy "Your journal will fill in here, one evening at a time."

### 3. Entry detail (`EntryDetail`)
- **Purpose:** Read a journal entry, listen to the original call, optionally view the transcript.
- **Layout:** Single column, max-width 680px, document-like reading layout.
  - Back chevron (top-left, IconBack), small date eyebrow ("Tuesday, March 12 · 7 min · 9:02pm"), large serif title (52px), the journal entry as flowing serif body text (Fraunces, 19px, 1.68 line-height, `text-wrap: pretty`).
  - **Audio player** card below the entry body (paper-2 background, 14px radius, 16px padding):
    - Play/pause button (40×40 circle, accent fill when playing).
    - Scrubber (4px height track, accent-filled progress, draggable).
    - Elapsed / total time on the right (tabular nums, serif, 22px).
  - **Transcript toggle** ("Show transcript" / "Hide transcript" — with a small chevron). Collapsed by default.
  - **Transcript view** when expanded: turn-by-turn dialog. Each turn has a small uppercase label (`QUOTID` or the user's name in mono 11px, 0.16em letter-spacing) above the speech (serif body, 17px, 1.6 line-height). Vertical rhythm of 28px between turns.

### 4. Calls list (`CallsList`)
- **Purpose:** A complete log of every call attempt — completed, missed, failed — with reasons.
- **Layout:** Same shell as Journal. Single column.
  - Page heading "Calls" (h1, serif).
  - Filter pills: All / Completed / Missed / Failed (toggle pills, accent when active).
  - Rows in reverse chrono order. Each `.call-row`:
    - Status icon (left, 32px, color-coded: completed = ink-2 phone, missed = bad-orange phone-missed, failed = warn-yellow alert).
    - Date + time (sans, 14px, two lines).
    - Status label + reason (serif, 17px on first line; small ink-3 reason below — e.g. "Picked up after 12s · Voicemail").
    - Duration on the right (tabular nums, mono 13px).
  - Click a completed row → opens that day's entry. Click a missed row → "Tap call back? · Outside hours" toast/modal.

### 5. Settings (`Settings`)
- **Purpose:** Configure phone, schedule, voice, account.
- **Layout:** Single column, sectioned. Each section is a labeled group with a label-left/control-right two-column row pattern.
  - **Schedule** — start/end time pickers (two `<input type="time">` elements styled as paper pills), days-of-week toggle (7 small circular toggles, accent fill when on).
  - **Voice** — grid of voice cards (3 columns desktop, 2 mobile). Each card: small avatar circle, voice name (serif 17px), one-line description (ink-3, 13px), play button (24px circle, accent when playing). Selected card has accent border + soft accent background.
  - **Phone number** — masked field showing existing number, "Change" link.
  - **Account** — email (display only), "Delete account" (small danger-styled link).
- All sections separated by a 1px paper-3 divider, 32px vertical spacing.

### 6. Live call overlay (`LiveCall`)
- **Purpose:** Full-screen "you are on the call right now" view.
- **Layout:** Fixed full-viewport overlay, dark background (`--night` `#1A1611`).
  - **Top bar:** small status row ("Calling" / "Live · End-to-end encrypted"), with a "Minimize" ghost button on the right (returns to Journal with status card showing "On the call").
  - **Center:** breathing avatar orb (140×140 in desktop, 100×100 mobile), two faint expanding rings around it (CSS keyframes `ring`), pulsed by `data-phase` (1.4s in dialing, 4s in-progress).
  - Below orb: serif title "Quotid" (32px), elapsed time / "Dialing your phone…" copy.
  - **Live caption slot** — when the AI speaks, a card appears with a small `QUOTID` label above the live caption text (serif 22px, with a blinking cursor while streaming).
  - **Bottom bar:**
    - Left: 5-bar mic meter (animated, accent color, dimmed when not in-progress).
    - Center-right: large red "End call" button (rounded pill, white text on `--bad`).

---

## The brand mark — "Q-cord" (C5)

The logo is a single continuous stroke that loops once to form a Q, then unspools into a coiled phone cord. It encodes the product (a phone-based journal) in one gesture: the Q is a moment in the cord where it loops back on itself.

- **Path** (SVG `viewBox="0 0 480 280"`):
  ```
  M 80 140 C 80 70, 140 40, 200 40 C 280 40, 320 100, 320 144 C 320 200, 280 240, 220 240 C 160 240, 88 220, 84 156 C 82 110, 130 84, 178 100 C 226 116, 252 168, 280 196 C 308 224, 332 230, 350 222 C 364 216, 368 202, 358 196 C 348 192, 342 204, 354 212 C 374 224, 396 224, 412 210 C 428 196, 432 178, 422 168 C 412 160, 398 168, 402 180 C 408 196, 432 200, 452 188
  ```
- **Stroke:** `fill="none"` `stroke="#C4502B"` `stroke-linecap="round"` `stroke-linejoin="round"`.
- **Stroke-width by size:**
  - Display (~280px): 22
  - Login mark (56px): 26
  - Topbar (22px): 28
  - Favicon (browser tab): 38

The wordmark is "quotid" set in **Fraunces, weight 500, italic, letter-spacing −0.02em**. In the lockup the mark sits to the left of the wordmark with 10px gap.

See `shell.jsx` → `QCordMark` component and `brand-explorations.html` for the exploration that arrived at this mark (variants C1–C5; C5 was selected).

---

## Design tokens

All tokens live in `styles.css` `:root` (light) and `[data-theme="dark"]`. Convert to your codebase's token system.

### Colors

**Light theme (paper):**
| Token | Value | Usage |
|---|---|---|
| `--paper` | `oklch(98% 0.008 80)` ≈ `#FBF4E8` | Page background |
| `--paper-2` | `oklch(96% 0.01 80)` | Subtle surface tint (audio player, hover) |
| `--paper-3` | `oklch(93% 0.012 80)` | Borders, dividers |
| `--paper-4` | `oklch(89% 0.015 80)` | Stronger borders |
| `--ink` | `oklch(20% 0.01 60)` ≈ `#1F1A14` | Primary text |
| `--ink-2` | `oklch(34% 0.012 60)` | Secondary text |
| `--ink-3` | `oklch(46% 0.012 60)` | Muted text, captions |
| `--accent` | `oklch(62% 0.16 55)` ≈ `#C4502B` | Brand mark, primary CTA, active states |
| `--accent-soft` | `oklch(92% 0.05 55)` | Soft accent surfaces |
| `--accent-ink` | `oklch(38% 0.13 55)` | Accent on accent-soft (links) |
| `--bad` | red-orange | Missed/failed/destructive |
| `--good` | green | Completed/success |
| `--warn` | amber | Warning |
| `--night` | `#1A1611` | Live call overlay only |

**Dark theme:** ink and paper invert per `[data-theme="dark"]` block in `styles.css`. Accent and brand mark remain.

The accent hue is exposed as `--accent-h: 55` so the accent palette can shift via a single value (used by the Tweaks panel in the prototype).

### Typography

| Family | Stack | Use |
|---|---|---|
| Display (serif) | `Fraunces, "Times New Roman", serif` | Headings, journal body, italic wordmark |
| UI (sans) | `Inter, system-ui, sans-serif` | Buttons, labels, navigation, body UI |
| Mono | `JetBrains Mono, ui-monospace, monospace` | Eyebrows, durations, speaker labels |

Load Fraunces 300–700 (variable, opsz 9–144), Inter 400/500/600, JetBrains Mono 400/500.

**Type scale:**
| Style | Size | Weight | Line-height | Family | Letter-spacing |
|---|---|---|---|---|---|
| h1 (page) | clamp(36, 4.4vw, 56) | 400 | 1.05 | display | -0.025em |
| h2 | 28px | 400 | 1.2 | display | -0.02em |
| Entry title | clamp(36, 5vw, 52) | 400 | 1.1 | display | -0.025em |
| Status title | 24px | 400 | 1.2 | display | -0.01em |
| Entry body | 19px | 400 | 1.68 | display | normal |
| UI body | 15px | 400 | 1.55 | UI | normal |
| Small | 13px | 400 | 1.5 | UI | normal |
| Mono eyebrow | 11px | 500 | 1 | mono | 0.16em uppercase |

### Spacing & sizing

8px base. Page horizontal padding: 24px mobile, 48px desktop. Card padding: 16–24px. Border radius: 6px (small), 10px (medium), 14px (cards), 18px (hero), 9999px (pills).

### Shadows

Generally avoided — the design uses borders and tonal contrast. Buttons use `oklch(0% 0 0 / 0.04–0.08)` 1–2px y-shadows only. The breathing orb has a colored glow `0 0 60px -10px oklch(60% 0.18 55 / 0.45)`.

---

## Interactions & motion

- **Page transitions:** none — the app is a single React tree with state-driven views. Use whatever animation primitive your stack offers (Framer Motion, View Transitions API, etc.) for entry/detail navigation; in the prototype it's instant.
- **Status card transitions:** when call state changes (idle → dialing → in-progress → idle), the card content swaps. Add a subtle fade/slide if your stack supports it; not required.
- **Pulse dot** (`<PulseDot />`): 8px circle with a 2.4s `pulse` keyframe (scale 1 → 1.6, opacity 0.7 → 0). Used in status card and live call.
- **Breathing orb** (`.call-stage__avatar`): `breathe` 4s ease-in-out infinite (transform: scale 1 → 1.06; box-shadow intensity tracks scale). Switches to 1.6s in `data-phase="dialing"`.
- **Ring animation** (`.call-stage__orb::before/::after`): ring expands from 100% to ~160% with fading opacity; staggered 0.7s.
- **Audio scrubber:** drag updates time live; click anywhere on the track jumps to position. Show a 12px thumb on hover/drag, hidden by default. The prototype uses real `<audio>` elements with mock URLs — your implementation can stub or wire to real audio.
- **Hover states:** entry rows tint to `--paper-2`. Buttons darken accent by `calc(l - 0.04)`. Transcript toggle chevron rotates 180°.
- **Focus states:** all interactive elements get a 2px `--accent` outline at 2px offset. Do not strip these.

---

## State

Top-level state in the prototype (`app.jsx` → `App`):
- `authed: bool` — gates Login.
- `route: 'journal' | 'calls' | 'settings'` — primary nav.
- `openEntryId: string | null` — when set, Journal renders `EntryDetail` instead of the index.
- `openCallEntry: object | null` — opens Live call overlay.
- `callState: 'idle' | 'dialing' | 'in-progress'` — drives status card and overlay.

In a real app these map to URL routes (e.g. `/`, `/calls`, `/settings`, `/entry/:id`) and the call state should come from the server (websocket or polling).

**Mock data lives in `data.js`** (`MOCK.entries`, `MOCK.calls`, `MOCK.voices`, `MOCK.user`, `MOCK.schedule`). Use it as the canonical shape for your real data model.

### Data shapes (lifted from mock)

```ts
// Entry
type Entry = {
  id: string;          // "2024-03-12"
  date: string;        // ISO
  title: string;       // "On the difficulty of saying no"
  snippet: string;     // first ~120 chars of body
  body: string;        // full markdown-able text (paragraphs separated by \n\n)
  duration: number;    // seconds of original call
  callTime: string;    // "21:02"
  audioUrl: string;
  transcript: { who: 'bot' | 'user'; text: string; t: number }[];
};

// Call (some calls have no entry — missed/failed)
type Call = {
  id: string;
  date: string;
  time: string;
  status: 'completed' | 'missed' | 'failed';
  reason?: string;     // "Voicemail", "User declined", etc.
  duration?: number;
  entryId?: string;    // present iff status === 'completed'
};

// Voice
type Voice = {
  id: string;
  name: string;        // "Iris"
  description: string; // "Warm, unhurried"
  sampleUrl: string;
};

// Schedule
type Schedule = {
  startMinutes: number;  // minutes since midnight (e.g. 1260 = 21:00)
  endMinutes: number;    // 1290 = 21:30
  days: number[];        // [0..6], 0 = Sunday
};
```

---

## Responsive behavior

**Breakpoint: 768px.**

- **≥768px (desktop):** Sidebar (220px) + main column. Sidebar contains brand lockup, nav, then footer with user pill + dark/light toggle + log out.
- **<768px (mobile):** Sticky topbar (56px) replaces sidebar. Hamburger button on left opens a left-drawer with the same nav contents. Main column gets reduced padding (24px → 18px).

Live call overlay is full-viewport on both. Voice cards: 3 cols → 2 cols at <768px. Entry body uses fluid `clamp()` sizes and stays comfortable at all widths.

---

## Files in this bundle

| File | Role |
|---|---|
| `Quotid Prototype.html` | Entry point. Loads React, Babel, scripts. **Open this in a browser to see the prototype.** |
| `app.jsx` | Top-level App component; routing + state + Tweaks. |
| `shell.jsx` | Brand mark, Sidebar, Topbar, Drawer, shared atoms (`PulseDot`, formatters), `QCordMark`. |
| `screens.jsx` | All six screens: `LoginScreen`, `JournalIndex`, `EntryDetail`, `CallsList`, `Settings`, `LiveCall`. |
| `icons.jsx` | All icons used (Book, Phone, Settings, Logout, Sun, Moon, Play, Pause, Back, etc.). Inline SVGs. |
| `data.js` | Mock entries, calls, voices, user, schedule. |
| `styles.css` | All design tokens + every component style. ~1250 lines. |
| `tweaks-panel.jsx` | The in-prototype Tweaks panel (accent hue, dark mode, type system, density, simulate states). **Not part of the product** — strip from production. |
| `brand-explorations.html` | Brand exploration document showing how the Q-cord mark was arrived at. Reference only. |
| `brand/logo.svg`, `brand/logo-mono.svg` | SVG exports of the brand mark. |

---

## Things NOT in the prototype that production will need

- Real auth (magic link, SMS OTP, etc.) — Login is a placeholder.
- Real telephony — outbound voice calls via Twilio/Vonage/etc., DTMF, voicemail detection.
- Real LLM voice agent + TTS (e.g. ElevenLabs or OpenAI Realtime).
- Server-side entry generation (LLM transcription → summarization).
- Push/SMS notifications around call windows.
- Onboarding (phone verification, voice picker, schedule setup) — currently absent.
- Search and tags inside Journal.
- Settings: notifications, time zone, billing.
- Privacy/data-export controls.

These were intentionally out of scope for the design phase.

---

## Recommended implementation stack (if greenfield)

- **Web:** Next.js (App Router) + Tailwind or vanilla CSS modules + shadcn or Radix primitives. The prototype's CSS is hand-rolled and translates directly to Tailwind tokens.
- **State:** Zustand or React Query — call state is server-driven so RQ or a websocket hook fits naturally.
- **Auth:** Clerk, Supabase Auth, or Auth.js with a magic link provider.
- **Telephony:** Twilio Voice + Twilio Media Streams for the Realtime path.
- **Audio:** native `<audio>` is fine for entry playback; use a small custom scrubber (the prototype's `.audio-player` is a good starting structure).

---

## Questions for the implementer

If anything is ambiguous, the prototype is the answer — open `Quotid Prototype.html`, toggle Tweaks (top-right) to inspect dark mode and other variants, and probe the actual rendered DOM. The CSS is fully readable.
