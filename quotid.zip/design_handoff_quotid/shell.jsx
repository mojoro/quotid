/* global React, MOCK, ICONS */
// Shared UI atoms

const { useState, useEffect, useRef, useMemo } = React;
const { IconBook, IconPhone, IconSettings, IconLogout, IconSun, IconMoon } = ICONS;

// C5 — the Q-cord. One continuous stroke that loops to form the Q,
// then unspools as a coiled phone cord. Same line, same weight, no break.
const QCORD_PATH = "M 80 140 C 80 70, 140 40, 200 40 C 280 40, 320 100, 320 144 C 320 200, 280 240, 220 240 C 160 240, 88 220, 84 156 C 82 110, 130 84, 178 100 C 226 116, 252 168, 280 196 C 308 224, 332 230, 350 222 C 364 216, 368 202, 358 196 C 348 192, 342 204, 354 212 C 374 224, 396 224, 412 210 C 428 196, 432 178, 422 168 C 412 160, 398 168, 402 180 C 408 196, 432 200, 452 188";

function QCordMark({ size = 28, strokeWidth = 28, color = "currentColor", className }) {
  return (
    <svg
      className={className}
      viewBox="0 0 480 280"
      width={size * (480 / 280)}
      height={size}
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d={QCORD_PATH}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function Brand() {
  return (
    <div className="brand">
      <div className="brand__mark" aria-hidden="true">
        <QCordMark size={22} strokeWidth={28} color="var(--accent)" />
      </div>
      <div className="brand__word">quotid</div>
    </div>
  );
}

// Expose to other modules
window.QCordMark = QCordMark;
window.QCORD_PATH = QCORD_PATH;

function Sidebar({ route, setRoute, onLogout, dark, onToggleTheme }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const links = [
    { id: "journal", label: "Journal", Icon: IconBook },
    { id: "calls", label: "Calls", Icon: IconPhone },
    { id: "settings", label: "Settings", Icon: IconSettings },
  ];

  function go(id) {
    setRoute(id);
    setMobileOpen(false);
  }

  // close drawer on Escape
  useEffect(() => {
    if (!mobileOpen) return;
    function onKey(e) { if (e.key === "Escape") setMobileOpen(false); }
    document.addEventListener("keydown", onKey);
    // lock body scroll while open
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [mobileOpen]);

  const navList = (
    <ul className="nav-list" role="list">
      {links.map((l) => {
        const Icn = l.Icon;
        const active = route === l.id;
        return (
          <li key={l.id}>
            <button
              type="button"
              className={"nav-link" + (active ? " is-active" : "")}
              onClick={() => go(l.id)}
              aria-current={active ? "page" : undefined}
            >
              <span className="nav-link__icon" aria-hidden="true"><Icn size={16} /></span>
              <span>{l.label}</span>
            </button>
          </li>
        );
      })}
    </ul>
  );

  const foot = (
    <div className="sidebar__foot">
      <div className="sidebar__id">
        <div className="avatar" aria-hidden="true">{MOCK.MOCK_USER.initials}</div>
        <div className="sidebar__email" title={MOCK.MOCK_USER.email}>{MOCK.MOCK_USER.email}</div>
      </div>
      <div className="sidebar__actions">
        <button
          type="button"
          className="ghost-btn"
          onClick={onToggleTheme}
          aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}
          aria-pressed={dark}
        >
          {dark ? <IconSun size={14} /> : <IconMoon size={14} />}
          <span>{dark ? "Light" : "Dark"}</span>
        </button>
        <button
          type="button"
          className="ghost-btn"
          onClick={onLogout}
          aria-label="Sign out"
        >
          <IconLogout size={14} />
          <span>Log out</span>
        </button>
      </div>
    </div>
  );

  return (
    <React.Fragment>
      {/* Desktop sidebar */}
      <aside className="sidebar" aria-label="Primary navigation">
        <Brand />
        <nav>{navList}</nav>
        {foot}
      </aside>

      {/* Mobile top bar */}
      <header className="topbar" aria-label="Primary navigation">
        <Brand />
        <div className="topbar__route" aria-live="polite">
          {links.find((l) => l.id === route)?.label}
        </div>
        <button
          type="button"
          className="topbar__menu"
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
          aria-expanded={mobileOpen}
          aria-controls="mobile-drawer"
          onClick={() => setMobileOpen((o) => !o)}
        >
          {mobileOpen ? (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M6 18L18 6"/></svg>
          ) : (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
          )}
        </button>
      </header>

      {/* Mobile drawer */}
      <div
        className={"drawer " + (mobileOpen ? "is-open" : "")}
        id="mobile-drawer"
        aria-hidden={!mobileOpen}
      >
        <button
          type="button"
          className="drawer__scrim"
          aria-label="Close menu"
          tabIndex={mobileOpen ? 0 : -1}
          onClick={() => setMobileOpen(false)}
        />
        <div className="drawer__panel" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="drawer__head">
            <Brand />
          </div>
          <nav className="drawer__nav">{navList}</nav>
          <div className="drawer__foot">{foot}</div>
        </div>
      </div>
    </React.Fragment>
  );
}

function PulseDot() { return <span className="pulse" aria-hidden="true" />; }

function fmtDuration(s) {
  if (s == null) return "—";
  const m = Math.floor(s / 60);
  const sec = String(s % 60).padStart(2, "0");
  return `${m}:${sec}`;
}
function fmtMonth(dateStr) {
  return new Date(dateStr).toLocaleString(undefined, { month: "long", year: "numeric" });
}
function fmtDay(dateStr) { return new Date(dateStr).getDate(); }
function fmtLong(dateStr) {
  return new Date(dateStr).toLocaleString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
}

window.UI = { Sidebar, PulseDot, fmtDuration, fmtMonth, fmtDay, fmtLong, QCordMark };
